Install VC_redist.x64.exe first.

Controls:

Move - WASD
Jump - Space
Dash - E
Dash (While in the air) - Space
Reset to checkpoint - R